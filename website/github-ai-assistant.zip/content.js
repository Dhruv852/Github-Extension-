// Ensure the script only runs once
if (!window.githubAIAssistantInitialized) {
  window.githubAIAssistantInitialized = true;

  class GitHubAIAssistant {
    constructor() {
      this.isEnabled = false;
      this.chatbotContainer = null;
      this.initialize();
    }

    async initialize() {
      // Check if extension is enabled and has API key
      const result = await chrome.storage.sync.get(['enabled', 'geminiKey']);
      this.isEnabled = result.enabled && result.geminiKey;
      
      if (this.isEnabled) {
        this.injectChatbotUI();
      }

      // Listen for messages from popup
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'toggleAssistant') {
          this.handleToggle(request.enabled);
          // Always send a response
          sendResponse({ success: true });
        }
        // Return true to indicate we'll send a response asynchronously
        return true;
      });
    }

    async handleToggle(enabled) {
      try {
        // Check for API key before enabling
        const { geminiKey } = await chrome.storage.sync.get(['geminiKey']);
        if (enabled && !geminiKey) {
          alert('Please set your Gemini API key in the extension settings before enabling the assistant.');
          chrome.storage.sync.set({ enabled: false });
          return;
        }

        this.isEnabled = enabled;
        if (this.isEnabled) {
          this.injectChatbotUI();
        } else {
          this.removeChatbotUI();
        }
      } catch (error) {
        console.error('Error handling toggle:', error);
      }
    }

    injectChatbotUI() {
      if (this.chatbotContainer) return;

      // Create chatbot container
      this.chatbotContainer = document.createElement('div');
      this.chatbotContainer.className = 'github-ai-assistant';
      
      // Create chatbot header
      const header = document.createElement('div');
      header.className = 'assistant-header';
      header.innerHTML = `
        <h3>GitHub AI Assistant</h3>
        <button class="minimize-btn">_</button>
      `;

      // Create chatbot content
      const content = document.createElement('div');
      content.className = 'assistant-content';
      content.innerHTML = `
        <div class="messages"></div>
        <div class="input-area">
          <textarea placeholder="Ask about this repository..."></textarea>
          <button class="send-btn">Send</button>
        </div>
      `;

      this.chatbotContainer.appendChild(header);
      this.chatbotContainer.appendChild(content);
      document.body.appendChild(this.chatbotContainer);

      // Add event listeners
      const minimizeBtn = header.querySelector('.minimize-btn');
      minimizeBtn.addEventListener('click', () => {
        this.chatbotContainer.classList.toggle('minimized');
      });

      const sendBtn = content.querySelector('.send-btn');
      const textarea = content.querySelector('textarea');
      
      sendBtn.addEventListener('click', () => this.handleUserMessage(textarea));
      textarea.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleUserMessage(textarea);
        }
      });

      // Initial repository analysis
      this.analyzeRepository();
    }

    removeChatbotUI() {
      if (this.chatbotContainer) {
        this.chatbotContainer.remove();
        this.chatbotContainer = null;
      }
    }

    async handleUserMessage(textarea) {
      const message = textarea.value.trim();
      if (!message) return;

      // Add user message to chat
      this.addMessage('user', message);
      textarea.value = '';

      try {
        // Check API key before sending message
        const { geminiKey } = await chrome.storage.sync.get(['geminiKey']);
        if (!geminiKey) {
          this.addMessage('assistant', 'Error: Please set your Gemini API key in the extension settings.');
          return;
        }

        // Send message to background script for API processing
        const response = await chrome.runtime.sendMessage({
          action: 'processMessage',
          message,
          repository: this.getRepositoryInfo()
        });

        if (response.error) {
          this.addMessage('assistant', `Error: ${response.error}`);
        } else {
          this.addMessage('assistant', response.reply);
        }
      } catch (error) {
        console.error('Error processing message:', error);
        this.addMessage('assistant', 'Sorry, there was an error processing your message.');
      }
    }

    addMessage(type, content) {
      const messagesContainer = this.chatbotContainer.querySelector('.messages');
      const messageDiv = document.createElement('div');
      messageDiv.className = `message ${type}-message`;
      messageDiv.innerHTML = content;
      messagesContainer.appendChild(messageDiv);
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    getRepositoryInfo() {
      const [owner, repo] = window.location.pathname.split('/').filter(Boolean);
      return { owner, repo };
    }

    async analyzeRepository() {
      const repoInfo = this.getRepositoryInfo();
      if (!repoInfo.owner || !repoInfo.repo) return;

      this.addMessage('assistant', 'Analyzing repository...');
      
      try {
        // Check API key before analysis
        const { geminiKey } = await chrome.storage.sync.get(['geminiKey']);
        if (!geminiKey) {
          this.addMessage('assistant', 'Error: Please set your Gemini API key in the extension settings.');
          return;
        }

        const response = await chrome.runtime.sendMessage({
          action: 'analyzeRepository',
          repository: repoInfo
        });

        if (response.error) {
          this.addMessage('assistant', `Error: ${response.error}`);
        } else {
          this.addMessage('assistant', response.analysis);
        }
      } catch (error) {
        console.error('Error analyzing repository:', error);
        this.addMessage('assistant', 'Unable to analyze repository at this time.');
      }
    }
  }

  // Initialize the assistant
  new GitHubAIAssistant();
}