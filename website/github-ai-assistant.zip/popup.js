document.addEventListener('DOMContentLoaded', async () => {
  const toggleBtn = document.getElementById('toggleBtn');
  const githubTokenInput = document.getElementById('githubToken');
  const geminiKeyInput = document.getElementById('geminiKey');
  const saveSettingsBtn = document.getElementById('saveSettings');
  const statusText = document.querySelector('.status-text');
  const statusDot = document.querySelector('.status-dot');
  const apiStatus = document.querySelector('.api-status');

  // Setup links
  document.getElementById('githubLink').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://github.com/settings/tokens?type=beta' });
  });

  document.getElementById('geminiLink').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://makersuite.google.com/app/apikey' });
  });

  // Load saved settings
  chrome.storage.sync.get(['enabled', 'githubToken', 'geminiKey'], (result) => {
    if (result.enabled) {
      toggleBtn.textContent = 'Disable Assistant';
      toggleBtn.classList.add('enabled');
      statusText.textContent = 'Active';
      statusDot.style.backgroundColor = '#2da44e';
    }
    if (result.githubToken) {
      githubTokenInput.value = result.githubToken;
    }
    if (result.geminiKey) {
      geminiKeyInput.value = result.geminiKey;
    }
  });

  // Toggle assistant
  toggleBtn.addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // Only proceed if we're on a GitHub page
      if (!tab.url.includes('github.com')) {
        alert('The AI Assistant only works on GitHub pages.');
        return;
      }

      const result = await chrome.storage.sync.get(['enabled', 'githubToken', 'geminiKey']);
      const newState = !result.enabled;
      
      // Check if both API keys are set before enabling
      if (newState && (!result.githubToken || !result.geminiKey)) {
        alert('Please enter both GitHub Token and Gemini API Key before enabling the assistant.');
        return;
      }

      await chrome.storage.sync.set({ enabled: newState });
      
      if (newState) {
        toggleBtn.textContent = 'Disable Assistant';
        toggleBtn.classList.add('enabled');
        statusText.textContent = 'Active';
        statusDot.style.backgroundColor = '#2da44e';
      } else {
        toggleBtn.textContent = 'Enable Assistant';
        toggleBtn.classList.remove('enabled');
        statusText.textContent = 'Inactive';
        statusDot.style.backgroundColor = '#cf222e';
      }

      // Inject content script if not already injected
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
      } catch (error) {
        // Script might already be injected, continue
      }

      // Notify content script
      try {
        await chrome.tabs.sendMessage(tab.id, { 
          action: 'toggleAssistant', 
          enabled: newState 
        });
      } catch (error) {
        // If the content script isn't ready, reload the page
        if (error.message.includes('Receiving end does not exist')) {
          chrome.tabs.reload(tab.id);
        }
      }
    } catch (error) {
      console.error('Error toggling assistant:', error);
      alert('Error toggling assistant. Please refresh the page and try again.');
    }
  });

  // Test GitHub token
  async function testGitHubToken(token) {
    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `token ${token}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  // Save settings
  saveSettingsBtn.addEventListener('click', async () => {
    const githubToken = githubTokenInput.value.trim();
    const geminiKey = geminiKeyInput.value.trim();
    
    if (!githubToken || !geminiKey) {
      alert('Please enter both GitHub Token and Gemini API Key');
      return;
    }

    try {
      // Test GitHub token
      apiStatus.textContent = 'Testing GitHub token...';
      apiStatus.style.color = '#0969da';
      
      const isValidToken = await testGitHubToken(githubToken);
      if (!isValidToken) {
        apiStatus.textContent = 'Error: Invalid GitHub token';
        apiStatus.style.color = '#cf222e';
        return;
      }

      // Save both keys
      await chrome.storage.sync.set({ 
        githubToken,
        geminiKey
      });
      
      // Show success message
      saveSettingsBtn.textContent = 'Saved!';
      saveSettingsBtn.style.backgroundColor = '#2da44e';
      apiStatus.textContent = 'API keys verified and saved successfully!';
      apiStatus.style.color = '#2da44e';
      
      // Reset button after 2 seconds
      setTimeout(() => {
        saveSettingsBtn.textContent = 'Save Settings';
        saveSettingsBtn.style.backgroundColor = '';
        apiStatus.textContent = '';
      }, 2000);

      // If the assistant is enabled, reload the active tab to apply new settings
      const { enabled } = await chrome.storage.sync.get('enabled');
      if (enabled) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url.includes('github.com')) {
          chrome.tabs.reload(tab.id);
        }
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      apiStatus.textContent = 'Error saving settings. Please try again.';
      apiStatus.style.color = '#cf222e';
    }
  });

  // Add input validation
  function validateInputs() {
    const githubToken = githubTokenInput.value.trim();
    const geminiKey = geminiKeyInput.value.trim();
    const isValid = githubToken && geminiKey;
    saveSettingsBtn.disabled = !isValid;
    saveSettingsBtn.style.opacity = isValid ? '1' : '0.5';
  }

  githubTokenInput.addEventListener('input', validateInputs);
  geminiKeyInput.addEventListener('input', validateInputs);

  // Initialize button state
  validateInputs();
}); 