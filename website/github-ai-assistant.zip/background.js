// Cache for API responses
const cache = new Map();

// GitHub API helper
class GitHubAPI {
  static async getHeaders() {
    const { githubToken } = await chrome.storage.sync.get(['githubToken']);
    if (!githubToken) {
      throw new Error('GitHub token not found. Please set it in the extension settings.');
    }
    return {
      'Authorization': `token ${githubToken}`,
      'Accept': 'application/vnd.github.v3+json'
    };
  }

  static async fetchWithAuth(url) {
    const headers = await this.getHeaders();
    const response = await fetch(url, { headers });
    
    if (response.status === 401) {
      throw new Error('Invalid GitHub token. Please check your token in the extension settings.');
    }
    
    if (response.status === 403) {
      throw new Error('GitHub API rate limit exceeded or insufficient permissions. Please check your token scopes.');
    }
    
    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status} - ${response.statusText}`);
    }

    return response.json();
  }

  static async fetchRepository(owner, repo) {
    const cacheKey = `repo:${owner}/${repo}`;
    if (cache.has(cacheKey)) {
      return cache.get(cacheKey);
    }

    const data = await this.fetchWithAuth(`https://api.github.com/repos/${owner}/${repo}`);
    cache.set(cacheKey, data);
    return data;
  }

  static async fetchFiles(owner, repo) {
    const cacheKey = `files:${owner}/${repo}`;
    if (cache.has(cacheKey)) {
      return cache.get(cacheKey);
    }

    const data = await this.fetchWithAuth(`https://api.github.com/repos/${owner}/${repo}/git/trees/main?recursive=1`);
    cache.set(cacheKey, data);
    return data;
  }

  static async fetchFileContent(owner, repo, path) {
    const cacheKey = `content:${owner}/${repo}/${path}`;
    if (cache.has(cacheKey)) {
      return cache.get(cacheKey);
    }

    const data = await this.fetchWithAuth(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`);
    const content = data.content ? atob(data.content) : '';
    cache.set(cacheKey, content);
    return content;
  }
}

// Gemini API helper
class GeminiAPI {
  static async getHeaders() {
    const { geminiKey } = await chrome.storage.sync.get(['geminiKey']);
    if (!geminiKey) {
      throw new Error('Gemini API key not found. Please set it in the extension settings.');
    }
    return {
      'Content-Type': 'application/json',
      'x-goog-api-key': geminiKey
    };
  }

  static formatResponse(text) {
    // Add consistent paragraph spacing and word wrap
    let formatted = text.replace(/\n{3,}/g, '\n\n');
    
    // Format bold text with proper HTML-like styling
    formatted = formatted.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
    
    // Format italics with proper styling
    formatted = formatted.replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
    
    // Format code blocks with syntax highlighting and proper spacing
    formatted = formatted.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
      return `\n<pre><code class="language-${lang || 'text'}">\n${code.trim()}\n</code></pre>\n`;
    });

    // Format inline code with proper styling
    formatted = formatted.replace(/`([^`\n]+)`/g, '<code>$1</code>');

    // Format bullet points with proper indentation and styling
    formatted = formatted.replace(/^\s*[-*]\s/gm, '• ');

    // Format blockquotes with proper styling
    formatted = formatted.replace(/^>\s*/gm, '<blockquote>');
    formatted = formatted.replace(/(?<=<blockquote>.*?)\n(?!>|\n)/g, '</blockquote>\n');

    // Format paragraphs with proper spacing
    formatted = formatted.split('\n').map(line => {
      if (line.length > 100 && !line.startsWith('<')) {
        const words = line.split(' ');
        let currentLine = '';
        return words.reduce((acc, word) => {
          if ((currentLine + ' ' + word).length > 100) {
            const result = acc + (acc ? '\n' : '') + currentLine;
            currentLine = word;
            return result;
          } else {
            currentLine = currentLine ? currentLine + ' ' + word : word;
            return acc;
          }
        }, '') + (currentLine ? '\n' + currentLine : '');
      }
      return line;
    }).join('\n');

    // Clean up excessive spacing while preserving HTML tags
    formatted = formatted
      .replace(/(?<!>)\s+(?!<)/g, ' ')
      .replace(/\n\s+/g, '\n')
      .replace(/\n{3,}/g, '\n\n');

    return formatted.trim();
  }

  static async generateResponse(prompt, context) {
    const headers = await this.getHeaders();
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `${prompt}\n\nContext:\n${JSON.stringify(context, null, 2)}`
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048
          }
        })
      });

      if (response.status === 401 || response.status === 403) {
        throw new Error('Invalid Gemini API key. Please check your API key in the extension settings.');
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`Gemini API error: ${response.status} - ${errorData.error?.message || response.statusText}`);
      }

      const data = await response.json();
      if (!data.candidates || !data.candidates[0]?.content?.parts?.[0]?.text) {
        throw new Error('Invalid response format from Gemini API. Please check if your API key has access to the Gemini Pro model.');
      }

      return this.formatResponse(data.candidates[0].content.parts[0].text);
    } catch (error) {
      console.error('Gemini API error:', error);
      throw error;
    }
  }
}

// Message handlers
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analyzeRepository') {
    handleRepositoryAnalysis(request.repository)
      .then(sendResponse)
      .catch(error => sendResponse({ error: error.message }));
    return true;
  }

  if (request.action === 'processMessage') {
    handleUserMessage(request.message, request.repository)
      .then(sendResponse)
      .catch(error => sendResponse({ error: error.message }));
    return true;
  }

  if (request.action === 'checkApiKey') {
    chrome.storage.sync.get(['githubToken', 'geminiKey'], (result) => {
      sendResponse({ 
        hasGithubToken: !!result.githubToken,
        hasGeminiKey: !!result.geminiKey
      });
    });
    return true;
  }
});

async function handleRepositoryAnalysis({ owner, repo }) {
  try {
    const [repoData, filesData] = await Promise.all([
      GitHubAPI.fetchRepository(owner, repo),
      GitHubAPI.fetchFiles(owner, repo)
    ]);

    const analysis = await GeminiAPI.generateResponse(
      'Analyze this GitHub repository and provide insights about its structure, code quality, and potential improvements.',
      { repository: repoData, files: filesData }
    );

    return { analysis };
  } catch (error) {
    console.error('Error analyzing repository:', error);
    throw error;
  }
}

async function handleUserMessage(message, repository) {
  try {
    const [repoData, filesData] = await Promise.all([
      GitHubAPI.fetchRepository(repository.owner, repository.repo),
      GitHubAPI.fetchFiles(repository.owner, repository.repo)
    ]);

    const reply = await GeminiAPI.generateResponse(message, {
      repository: repoData,
      files: filesData,
      userMessage: message
    });

    return { reply };
  } catch (error) {
    console.error('Error processing message:', error);
    throw error;
  }
}

// Clear cache when extension is updated or reloaded
chrome.runtime.onInstalled.addListener(() => {
  cache.clear();
});